import streamlit as st
from main import summarize_text

st.title("💰 Financial News Summarizer")

text = st.text_area("Enter Financial News Article:")

if st.button("Summarize"):
    if text.strip() == "":
        st.warning("Please enter some text")
    else:
        summary = summarize_text(text, top_n=3)
        st.subheader("Summary:")
        for line in summary:
            st.write("- " + line)
